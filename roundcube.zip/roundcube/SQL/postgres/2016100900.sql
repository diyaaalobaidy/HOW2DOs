ALTER TABLE session ALTER COLUMN ip TYPE character varying(41);
